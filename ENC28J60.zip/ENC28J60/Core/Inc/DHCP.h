/*
 * DHCP.h
 *
 *  Created on: Mar 24, 2019
 *      Author: Arethusa
 */

#ifndef DHCP_H_
#define DHCP_H_

#include "STM_ENC28_J60.h"

#define DHCPDEBUG 0

#endif /* DHCP_H_ */
